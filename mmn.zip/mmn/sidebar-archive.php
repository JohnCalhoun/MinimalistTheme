<div id="sidebar-primary" class="sidebar">
     <?php if ( is_active_sidebar( 'archive-sidebar' ) ) : ?>
          <?php dynamic_sidebar( 'archive-sidebar' ); ?>
     <?php endif; ?>
</div>
