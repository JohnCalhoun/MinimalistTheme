<div id="sidebar-primary" class="sidebar">
     <?php if ( is_active_sidebar( 'single-sidebar' ) ) : ?>
          <?php dynamic_sidebar( 'single-sidebar' ); ?>
     <?php endif; ?>
</div>
