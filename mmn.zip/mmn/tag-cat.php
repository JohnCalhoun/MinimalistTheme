<div class="entry-meta">
     <div class="row">
     <div class="col-xs-6 text-left">
          <p><?php the_tags('',':',''); ?></p>
     </div>
     <div class="col-xs-6 text-right">
          <p><?php the_category(':'); ?></p>
     </div>
     </div>
</div>

