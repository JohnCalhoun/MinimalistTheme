</div>
</div>
<div class="row">
<?php get_template_part('footer_nav') ?>
</div>
</div>
<?php wp_footer(); ?>

</body>
</html>
