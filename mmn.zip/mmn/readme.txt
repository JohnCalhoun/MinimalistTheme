This is a minimalist theme for wordpress developed first for the personal webiste of John M Calhoun. 
