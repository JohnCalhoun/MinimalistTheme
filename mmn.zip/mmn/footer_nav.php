<div class="text-center" id="footer">
<?php wp_nav_menu( array(
                    'main_menu'=>'Main menu',
                    'depth'=>1,
                    'menu_class'=>'main_menu',
                    'before'=>'',
                    'after'=> '',
                    'theme_location'=>'main_menu'
               )); ?> 
</div>
</div>
