<?php get_header(); ?>

	<div id="content">
	
	<h2><a href="/"><?php bloginfo('name'); ?></a> : <b>page lost, a haiku</b></h2>
<br>
<br>
our search is lonely<br>
a footprint left in pure snow<br>
blown into <a href="<?php echo home_url(); ?>/">nothing</a>
	</div>

<?php get_footer(); ?>
